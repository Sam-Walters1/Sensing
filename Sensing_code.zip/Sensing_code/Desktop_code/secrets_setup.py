# Lets get some stuff done. We're gonna:
#      - Upload data to an online doc
#      - Get refreshing access tokens so it can run indefinitely

from urllib.parse import urlencode
import base64

client_secret = '216af30e17d04364ad6938d171f3dfd9'
scopes = ['user-read-currently-playing', 'user-read-playback-state']
print('%20'.join(scopes))

query_dict = {
    'client_id': '9828783b1b8b4acbafe59cefef373f98',
    'response_type': 'code',
    'redirect_uri': 'https://samcwalters.com/',
    'scope': 'user-read-currently-playing user-read-playback-state'
}

query_string = 'https://accounts.spotify.com/authorize?' + urlencode(query_dict, doseq=True)

basic = "https://accounts.spotify.com/authorize?client_id=9828783b1b8b4acbafe59cefef373f98&response_type=code&redirect_uri=https:%2F%2Fsamcwalters.com%2F&scope=user-read-currently-playing%20user-read-playback-state"
base64_thang = '9828783b1b8b4acbafe59cefef373f98:216af30e17d04364ad6938d171f3dfd9'
base64_thang_encoded = base64.b64encode(base64_thang.encode('ascii'))

curl -H "Authorization: Basic OTgyODc4M2IxYjhiNGFjYmFmZTU5Y2VmZWYzNzNmOTg6MjE2YWYzMGUxN2QwNDM2NGFkNjkzOGQxNzFmM2RmZDk=" -d grant_type=authorization_code -d code=AQBGO-SW9QfPgSQUVyw1kqGLzXpTVWn25vqpEXpCMXtP1s74o4o4VUSIU9HZykJ3FySTe3hXNh5h3FoQWSNCz1C0pCWVoUmtE5QfFNe1jbgraXoBP1ulnLCT5cVNZwcV5HE7MGBLmFoUetzKCZ0HbxUclKSljBZk5pdQsOj-lNx5-D3myQH8JcfjBPypCMwKJPU_u9Z46St06YeHoTTMhDLUmUPbFpaj6dv3MAuhkm59G8c -d redirect_uri=https%3A%2F%2Fsamcwalters.com%2F https://accounts.spotify.com/api/token --ssl-no-revoke
