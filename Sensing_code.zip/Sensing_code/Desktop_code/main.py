# SENSING and IOT: SPOTIFY API CODE
#
# The purpose of this code is to collect information on what songs I listen to throughout the day, for the 
# purpose of determining wether my listening habits have any significant impact on my guitar playing habits.


#-------------------------------------------- IMPORTS ---------------------------------------------------#

import requests
import time
import collections
from pprint import pprint
from datetime import datetime

import gspread 
from oauth2client.service_account import ServiceAccountCredentials

from refresh import Refresh
from secrets import spotify_user_id



#------------------------------ DEFINING GLOBAL VARIABLES AND CONSTANTS ------------------------------------#

KEY_REF = ('C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B')                   # Converts Spotify's numeric values into the respective keys
SPOTIFY_GET_CURRENT_TRACK_URL = 'https://api.spotify.com/v1/me/player/currently-playing'      # Link to the currently-playing manager for Spotify's API
SPOTIFY_GET_TRACKS_AUDIO_FEATURES = 'https://api.spotify.com/v1/audio-features/'              # Link to the audio-features manager for Spotify's API
SPOTIFY_GET_ARTIST = 'https://api.spotify.com/v1/artists/'                                    # Link to the get-artist manager for Spotify's API

SAMPLING_RATE = 60            # 60 second sampling rate. This is bc the shortest song on my playlist is around 2 minutes long, and to ensure no data is missed I sample at half the shortest measurement
REFRESH_TIME = 3300           # Spotify's Access codes expire after 3600 seconds (1 hour), so to compensate for potential latency I'm assuming a refresh rate of 3300 seconds (55 minutes)

GOOGLE_SHEET = "Sensing_&_IoT-Spotify_Dataset"
spotify_access_token = ''     # Starts as an empty string, since it's defined in the main() function by connecting directly to Spotify's API and requesting a key




#---------------------------------------- UTILITY FUNCTIONS -------------------------------------------------#

# Sends a request for the current song that's being played on my device to the Spotify API,
# and returns info about the current song, such as it's name, album, artist, etc. After getting these, 
# it calls on the get_track_audio_features function

def open_google_sheet(sheet_name):
    scope = ["https://spreadsheets.google.com/feeds","https://www.googleapis.com/auth/spreadsheets","https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open(sheet_name).sheet1
    return sheet

def next_available_row(sheet):
    str_list = list(filter(None, sheet.col_values(1)))
    return len(str_list)+1


def get_current_track(access_token):

    # Requesting current track information from Spotify, using the temporary Access Code 
    response = requests.get(SPOTIFY_GET_CURRENT_TRACK_URL,
        headers = {"Authorization": f"Bearer {access_token}"})

    try:

        resp_json = response.json()

    except:
        return None, None, None

    # Extracting only the necessary data from the resultant JSON file and declaring them as variables
    track_id = resp_json['item']['id']
    track_name = resp_json['item']['name']
    artists = resp_json['item']['artists'] 
    artists_name = [artist['name'] for artist in artists]
    artists_id = [artist['id'] for artist in artists]
    album = resp_json['item']['album']['name']
    popularity = resp_json['item']['popularity']

    # Inserting all the collected values into an easy-to-read dictionary
    current_track_info = {
        "album": album,
        "name": track_name,
        "artist": artists_name,
        "artists_id": artists_id,
        "id": track_id,
        "popularity": popularity
    }

    current_audio_features = get_track_audio_features(access_token, track_id)
    current_artists_info = [get_artists_info(access_token, artist) for artist in artists_id]

    return current_track_info, current_audio_features, current_artists_info

# ------------------------------------------------------------------------------------------------------------

# Takes the current playing song's ID, and sends it to the spotify API to perform audio analysis on. 
# From this, get interesting features such as tempo, valence, danceability, energy, etc. It also provides
# an estimate at the key it's being played in, but in my experience this tends to be rather temperamental.

def get_track_audio_features(access_token, song_id):
    
    # Requesting audio feature information from Spotify, using the temporary Access Code 
    response = requests.get(SPOTIFY_GET_TRACKS_AUDIO_FEATURES + song_id,
        headers = {"Authorization": f"Bearer {access_token}"})
    
    resp_json = response.json()

    # Extracting only the necessary data from the resultant JSON file and declaring them as variables
    try: 
        danceability = resp_json['danceability']
        energy = resp_json['energy']
        key = KEY_REF[resp_json['key']]
        valence = resp_json['valence']
        tempo = resp_json['tempo']
        duration_s = resp_json['duration_ms']/1000
        time_sig = resp_json['time_signature']

        # Inserting collected values into an easy-to-read dictionary
        current_audio_features = {
        "Danceability": danceability,
        "Energy": energy,
        "Key": key,
        "Valence": valence,
        "Tempo (BPM)": tempo,
        "Length (s)": duration_s,
        "Time Signature": time_sig
        }
    except KeyError:
        print("No Audio Features found. Continuing.")
        current_audio_features = {
        "Danceability": 0,
        "Energy": 0,
        "Key": "N/A",
        "Valence": 0,
        "Tempo (BPM)": 0,
        "Length (s)": 0,
        "Time Signature": 0
        }
    
    return current_audio_features

# ------------------------------------------------------------------------------------------------------------

# Spotify doesn't supply genre information on a song-by-song basis, but they do provide the artist's genres.
# So, for each song the artist's information is requested and the genre information extracted.
# Since we've already gotten access to the artists information, we also extract their followers so I can 
# determine how basic I am in terms of the average follower count of artists that I listen to.

def get_artists_info(access_token, artist_id):

    # Requesting artist information from Spotify, using the temporary Access Code
    response = requests.get(SPOTIFY_GET_ARTIST + artist_id,
        headers = {"Authorization": f"Bearer {access_token}"})

    resp_json = response.json()

    # Extracting only the necessary data from the resultant JSON file and declaring them as variables
    followers = resp_json['followers']['total']
    genres = resp_json['genres']

    # Inserting collected values into an easy-to-read dictionary
    artist_info = {
        "Followers": followers,
        "Genres": genres
    }

    return artist_info

# ------------------------------------------------------------------------------------------------------------

# Collects the list of genres, and sorts them based on how many times each genre appeared in all the songs I've 
# listened to that day. From this, it extracts the top three genres and returns them as a list.

def get_top_genres(genres):
    ordered_genres = collections.OrderedDict(sorted(genres.items(), key=lambda x: x[1]))
    top_genres = list(ordered_genres.keys())[-3:]
    return top_genres[::-1]



#--------------------------------------- MAIN FUNCTION -----------------------------------------------------#

# Initiates a loop that goes on forever. Sends a request to the Spotify API every 45 seconds, and loops through
# each of the utility functions listed above to get information on each of the songs.

def main():

    song_list = []
    genre_tally = {}
    spotify_access_token = Refresh().refresh()

    sheet = open_google_sheet(GOOGLE_SHEET)

    now = datetime.now()

    refresh_target = int(REFRESH_TIME/SAMPLING_RATE)
    refresh_counter = 0
    
    while True:

        current_track_info, current_audio_features, current_artists_info = get_current_track(spotify_access_token)
        
        try:
            if current_track_info["name"] == song_list[-1]:
                print('Same song playing. Continue.')
            else:
                song_list.append(current_track_info["name"])
                for artist in current_artists_info:
                    for genre in artist["Genres"]:
                        if genre in genre_tally:
                            genre_tally[genre] = genre_tally[genre] + 1
                        else:
                            genre_tally[genre] = 1

                now = datetime.now()
                entry_date = now.strftime("%d/%m/%Y")
                entry_time = now.strftime("%H:%M:%S")
                entry_number = next_available_row(sheet)
                print('entry number', entry_number)
                pprint(current_track_info, indent = 4)
                #pprint(current_audio_features, indent = 4)
                pprint(current_artists_info, indent = 4)

                feature_list = [
                    entry_number-1, 
                    entry_date, 
                    entry_time, 
                    current_track_info["name"],
                    ', '.join(current_track_info["artist"]), 
                    current_track_info["album"],
                    current_audio_features["Length (s)"],
                    ', '.join([str(artist["Genres"]) for artist in current_artists_info]), 
                    current_track_info["popularity"],
                    ', '.join([str(artist["Followers"]) for artist in current_artists_info]), 
                    current_audio_features["Danceability"],
                    current_audio_features["Energy"],
                    current_audio_features["Key"],
                    current_audio_features["Valence"],
                    current_audio_features["Tempo (BPM)"],
                    current_audio_features["Time Signature"]
                ]

                sheet.insert_row(feature_list, entry_number)

        except IndexError:
            song_list.append(current_track_info["name"])
            for artist in current_artists_info:
                for genre in artist["Genres"]:
                    if genre in genre_tally:
                        genre_tally[genre] = genre_tally[genre] + 1
                    else:
                        genre_tally[genre] = 1
            
            now = datetime.now()
            entry_date = now.strftime("%d/%m/%Y")
            entry_time = now.strftime("%H:%M:%S")
            entry_number = next_available_row(sheet)
            print('entry number', entry_number)
            pprint(current_track_info, indent = 4)
            #pprint(current_audio_features, indent = 4)
            pprint(current_artists_info, indent = 4)

            feature_list = [
                entry_number-1, 
                entry_date, 
                entry_time, 
                current_track_info["name"],
                ', '.join(current_track_info["artist"]), 
                current_track_info["album"],
                current_audio_features["Length (s)"],
                ', '.join([str(artist["Genres"]) for artist in current_artists_info]), 
                current_track_info["popularity"],
                ', '.join([str(artist["Followers"]) for artist in current_artists_info]), 
                current_audio_features["Danceability"],
                current_audio_features["Energy"],
                current_audio_features["Key"],
                current_audio_features["Valence"],
                current_audio_features["Tempo (BPM)"],
                current_audio_features["Time Signature"]
            ]

            sheet.insert_row(feature_list, int(entry_number))

            pass

        except TypeError:
            print('Spotify is not running. Passing.')
            pass
        
        refresh_counter += 1
        
        time.sleep(SAMPLING_RATE)

        if refresh_counter == refresh_target:
            spotify_access_token = Refresh().refresh()
            refresh_counter = 0
            print('Access Token Refreshed.')

        


if __name__ == '__main__':
    main()