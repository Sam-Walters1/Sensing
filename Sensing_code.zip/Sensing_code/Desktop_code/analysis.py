
import collections
import gspread 
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime
from pprint import pprint

PEDAL_GOOGLE_SHEET = "Pedal_Info"
SPOTIFY_GOOGLE_SHEET = "Sensing_&_IoT-Spotify_Dataset"
GENRE_POST_SHEET = "Genre_Summarised_Info"

#keys = result[0:limit]
#print(keys)

NOTE_REF = ("A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#")
SCALE_REF = ("C_Major","D_Major","E_Major","F_Major","G_Major","A_Major","B_Major","Gs_Major","As_Major","Cs_Major","Ds_Major","Fs_Major","A_Minor","B_Minor","C_Minor","D_Minor","E_Minor","F_Minor","G_Minor")

clean_genres = (
    "classical",
    "classical era",
    "avant-garde",
    "post-romantic era",
    "early romantic era",
    "classical performance",
    "orchestral performance",
    "late romantic era",
    "baroque",
    "classical piano",
    "lo-fi",
    "lo-fi beats",
    "focus beats",
    "chillhop",
    "lo-fi jazzhop",
    "lo-fi chill",
    "japanese chillhop",
    "anime lo-fi",
    "chill out",
    "background jazz",
    "contemporary jazz",
    "jazz",
    "jazz piano",
    "jazz fusion",
    "bobop",
    "dinner jazz",
    "ambient"
)

booster_genres = (
    "disco",
    "funk",
    "post-disco",
    "quiet storm",
    "adult standards",
    "soul",
    "motown",
    "new wave",
    "new wave pop",
    "soft rock",
    "europop",
    "acoustic punk"
)

bit_cruncher_genres = (
    "brostep",
    "dubstep",
    "filthstep",
    "drum and bass",
    "classic dubstep",
    "modern indie pop",
    "pop",
    "pop rock",
    "alternative pop rock",
    "indie pop",
    "complextro",
    "dance pop",
    "bass house"
)

distortion_genres = (
    "alternative rock",
    "indie rock",
    "anti-folk",
    "indie-pop",
    "modern rock",
    "modern alternative rock",
    "rock",
    "grunge",
    "garage rock",
    "alternative dance",
    "emo",
    "new rave",
    "melancholia",
    "art pop",
    "stomp and holler",
    "alternative dance",
    "alternative hip hop"
)

fuzz_genres = (
    "alternative metal", 
    "glam metal",
    "industrial metal",
    "classic rock",
    "hard rock",
    "art rock",
    "metal",
    "album rock",
    "funk metal",
    "post-grunge"
)

synth_genres = (
    "future funk",
    "vaporwave",
    "indietronica",
    "house",
    "permanent wave",
    "electro house",
    "edm"
)

now = datetime.now()

date = now.strftime("%d/%m/%Y")
date_stamp = now.strftime("%H:%M:%S")
print(date)
data_point = 25

MONTH_DICT = {
    "January": "01",
    "February": "02",
    "March": "03",
    "April": "04",
    "May": "05",
    "June": "06",
    "July": "07",
    "August": "08",
    "September": "09",
    "October": "10",
    "November": "11",
    "December": "12"
}

SCALE_DICT = {
"C_Major": ["C","D","E","F","G","A","B"],
"D_Major": ["D","E","F#","G","A","B","C#"],
"E_Major": ["E","F#","G#","A","B","C#","D#"],
"F_Major" : ["F","G","A","A#","C","D","E"],
"G_Major": ["G","A","B","C","D","E","F"],
"A_Major": ["A","B","C#","D","E","F#","G#"],
"B_Major": ["B","C#","D#","E","F#","G#","A#"],
"Gs_Major": ["G#","A#","C","C#","D#","F","G"],
"As_Major": ["A#","C","D","D#","F","G","A"],
"Cs_Major": ["C#","D#","E#","F#","G#","A#","C"],
"Ds_Major": ["D#","F","G","G#","A#","C","D"],
"Fs_Major": ["F#","G#","A#","B","C#","D","F"],
"A_Minor": ["A","B","C","D","E","F","G"],
"B_Minor": ["B","C#","D","E","F#","G","A"],
"C_Minor": ["C","D","D#","F","G","G#","A#"],
"D_Minor": ["D","E","F","G","A","A#","C"],
"E_Minor": ["E","F#","G","A","B","C","D"],
"F_Minor": ["F","G","G#","A#","C","C#", "D#"],
"G_Minor": ["G","A","A#","C","D","D#","F"],
}


def open_google_sheet(json_path, sheet_name):
    scope = ["https://spreadsheets.google.com/feeds","https://www.googleapis.com/auth/spreadsheets","https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name(json_path, scope)
    client = gspread.authorize(creds)
    sheet = client.open(sheet_name).sheet1
    return sheet


def get_todays_data(dataset, datatype):
    i = 0
    todays_data = []
    if datatype == "pedal" :
        for row in dataset:
            data_date = correct_date_format(row["Timestamp"].split(", "))
            if data_date == date:
                todays_data.append(dataset[i])
            i += 1
    elif datatype == "spotify":
        for row in dataset:
            if row["Date"] == date:
                todays_data.append(dataset[i])
            i += 1
        
    return todays_data


    

def correct_date_format(unedited_date):
    month = MONTH_DICT[unedited_date[0].split(" ")[0]]
    day = unedited_date[0].split(" ")[1]
    if len(day) != 2:
        day = "0" + day
    year = unedited_date[1].split(" ")[0]
    corrected_date = "{}/{}/{}".format(day,month,year)
    return corrected_date


def key_find_hard(notes):
    # Eliminate the keys that don't have the most popular notes played
    scale_possibilities = list(SCALE_REF[:])
    prev_possibilities = []
    notes = notes[:7]
    for note in notes:
        for scale in SCALE_DICT:
            if note not in SCALE_DICT[scale]:
                try:
                    scale_possibilities.remove(scale)
                except ValueError:
                    pass
        if len(scale_possibilities) == 1:
            predicted_key = scale_possibilities[0]
            return predicted_key
        elif len(scale_possibilities) == 0:
            predicted_key = narrow_notes(notes,prev_possibilities)
            return predicted_key
        prev_possibilities = scale_possibilities[:]
    predicted_key = narrow_notes(notes,scale_possibilities)
    return predicted_key


def narrow_notes(notes, possibilities):
    for note in notes:
        for key in possibilities:
            if note[0] == key[0]:
                return key
    return str("No scale found.")


def get_note_order(reading):
    #notes_tally = [row["Notes_Tally"] for row in data]
    notes_tally = reading["Notes_Tally"].split(" ")
    notes_tally = [ int(i) for i in notes_tally]
    notes_dict = {
        "A": notes_tally[0],
        "A#": notes_tally[1], 
        "B": notes_tally[2], 
        "C": notes_tally[3],
        "C#": notes_tally[4],
        "D": notes_tally[5], 
        "D#": notes_tally[6], 
        "E": notes_tally[7],
        "F": notes_tally[8],
        "F#": notes_tally[9], 
        "G": notes_tally[10], 
        "G#": notes_tally[11] 
    }
    sorted_notes_dict = sorted(notes_dict.items(), key = lambda x: x[1], reverse = True)
    sorted_notes = [item[0] for item in sorted_notes_dict]
    return sorted_notes, notes_dict


def get_dissonance(notes_dict, key):
    total_notes = sum(notes_dict[v] for v in notes_dict)
    dissonant_note_total = 0
    for note in notes_dict:
        try:
            if note not in SCALE_DICT[key]:
                dissonant_note_total += notes_dict[note]
        except KeyError:
            return 0
    dissonance = dissonant_note_total/total_notes
    return round(dissonance, 3)


def get_reading_data(reading):

    frequency = reading["Average_Frequency"]
    energy = reading["Energy"]

    sorted_notes, notes_dict = get_note_order(reading)
    key = key_find_hard(sorted_notes)
    dissonance = get_dissonance(notes_dict, key)

    reading_data = (frequency, energy, key, dissonance)
    
    return reading_data


def get_common_key(dataset):
    key_dict = {}
    keys = [item[2] for item in dataset]
    for k in keys:
        if k in key_dict:
            key_dict[k] += 1
        else:
            key_dict[k] = 1
    sorted_key_dict = sorted(key_dict.items(), key = lambda x: x[1], reverse = True)
    sorted_keys = [item[0] for item in sorted_key_dict]

    return sorted_keys


def get_top_genres(dataset):

    genre_tally = {}
    for row in dataset:
        temp = row["Genres"].replace('\'','').replace('[','').replace(']','')
        corrected_list = temp.split(', ')
        for genre in corrected_list:
            if genre in genre_tally:
                genre_tally[genre] += 1
            else:
                genre_tally[genre] = 1

    del genre_tally['']
    ordered_genres = collections.OrderedDict(sorted(genre_tally.items(), key=lambda x: x[1]))
    top_genres = list(ordered_genres.keys())[-3:]
    return top_genres[::-1]

def get_pedal_mode(top_genre):

    if top_genre in clean_genres: return "clean"
    elif top_genre in booster_genres: return "booster"
    elif top_genre in bit_cruncher_genres: return "bit_cruncher"
    elif top_genre in distortion_genres: return "distortion"
    elif top_genre in fuzz_genres: return "fuzz"
    elif top_genre in synth_genres: return "synth"
    else: return "misc" 


def main():

    collated_pedal_data = []
    collated_spotify_data = []

    pedal_sheet = open_google_sheet("pedal_creds.json", PEDAL_GOOGLE_SHEET)
    pedal_dataset = pedal_sheet.get_all_records()
    pedal_data = get_todays_data(pedal_dataset, "pedal")

    spotify_sheet = open_google_sheet("spotify_creds.json", SPOTIFY_GOOGLE_SHEET)
    spotify_datasheet = spotify_sheet.get_all_records()
    spotify_data = get_todays_data(spotify_datasheet, "spotify")

    genre_sheet = open_google_sheet("genre_creds.json", GENRE_POST_SHEET)
    


    p = 0
    for row in pedal_data:
        temp = get_reading_data(pedal_data[p])
        collated_pedal_data.append(temp)
        p += 1
    try:
        total_avg_frequency = sum(row["Average_Frequency"] for row in pedal_data)/len(pedal_data)
        total_avg_energy = sum(row["Energy"] for row in pedal_data)/len(pedal_data)
        total_avg_dissonance = sum(row[3] for row in collated_pedal_data)/len(collated_pedal_data)
        top_keys = get_common_key(collated_pedal_data)

        print("Time Played: ", len(collated_pedal_data), "minutes")
        print("Average Frequency: ", round(total_avg_frequency,0))
        print("Top 3 Keys: ", top_keys[:3])
        print("Average Energy: ", round(total_avg_energy, 2))
        print("Average Dissonance: ", round(total_avg_dissonance, 2))

    except ZeroDivisionError:
        print("No Pedal data collected so far today.")

    
    total_listening_time = sum(row["Duration"] for row in spotify_data)/3600
    average_spotify_energy = sum(row["Energy"] for row in spotify_data)/len(spotify_data)
    average_valence = sum(row["Valence"] for row in spotify_data)/len(spotify_data)
    average_tempo = sum(row["Tempo"] for row in spotify_data)/len(spotify_data)
    top_genres = get_top_genres(spotify_data)
    print("\nTotal Listening Time: ", round(total_listening_time,1),"hours")
    print("Average Energy: ", round(average_spotify_energy,2))
    print("Average Valence: ", round(average_valence,2))
    print("Average tempo: ", round(average_tempo,0))
    print("Top genres: ", top_genres)

    pedal_mode = get_pedal_mode(top_genres[0])
    print("Pedal Mode to be sent: ", pedal_mode)

    genre_sheet.update_cell(2,1, pedal_mode)
    genre_sheet.update_cell(2,2, date + ", " + date_stamp)


if __name__ == '__main__':
    main()